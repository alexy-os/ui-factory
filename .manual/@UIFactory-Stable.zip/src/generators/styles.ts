import * as fs from 'fs/promises';
import * as path from 'path';
import postcss from 'postcss';
import tailwindcss from 'tailwindcss';
import autoprefixer from 'autoprefixer';

export class StyleProcessor {
  private async processStyles(css: string): Promise<string> {
    const result = await postcss([
      tailwindcss,
      autoprefixer
    ]).process(css, {
      from: undefined
    });

    return result.css;
  }

  async bundleStyles(srcPath: string, outDir: string): Promise<string> {
    // Читаем основной CSS файл
    const cssContent = await fs.readFile(srcPath, 'utf-8');
    
    // Обрабатываем через PostCSS и Tailwind
    const processedCss = await this.processStyles(cssContent);
    
    // Создаем выходной файл
    const outputPath = path.join(outDir, 'style.css');
    await fs.writeFile(outputPath, processedCss, 'utf-8');
    
    return 'style.css'; // Возвращаем относительный путь к файлу
  }
} 