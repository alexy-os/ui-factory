import React from 'react';
import { Button } from "@/components/ui/button";

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <div className="container mx-auto py-10">
        <header className="mb-8">
          <h1 className="text-4xl font-bold">UI Factory</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            A collection of reusable UI components from popular React libraries
          </p>
        </header>

        <main>
          <section className="space-y-4">
            <div className="flex gap-4">
              <Button variant="default">Default Button</Button>
              <Button variant="secondary">Secondary Button</Button>
              <Button variant="outline">Outline Button</Button>
              <Button variant="ghost">Ghost Button</Button>
            </div>

            <div className="grid gap-4 mt-8">
              <div className="p-6 bg-card text-card-foreground rounded-lg border">
                <h2 className="text-2xl font-semibold">Card Example</h2>
                <p className="text-muted-foreground mt-2">
                  This is a card component with shadcn/ui styling
                </p>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}; 